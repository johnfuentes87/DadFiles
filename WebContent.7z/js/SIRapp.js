// Customer Name - Name of Customer
//
// This file should be located in the application directory and edited on 
// instructions from Intervoice Personnel ONLY.
// It contains important CDR billing information. Each hosted application directory
// has a unique customer_id (aka application_id) assigned by Intervoice Managed Services.
// If you do not know this number, please call the Intervoice Managed Services' Operations Manager.
//
var CustomerID='165';










