session.SIR = new Object();
if ((session.telephone.dnis==null) || isNaN(session.telephone.dnis)) {
   session.SIR.dnis=0;
} else {
   session.SIR.dnis=session.telephone.dnis;
}
if ((session.telephone.ani==null) || isNaN(session.telephone.ani)) {
   session.SIR.ani=0;
} else {
   session.SIR.ani=session.telephone.ani;
}
session.SIR.startTime=new Date();
session.SIR.callSeqNbr=session.telephone.callid;
session.SIR.line=session.telephone.line;
session.SIR.delim='\t'; 	//comma required for version number 4720 (SIRlog_rename_4720.cmd).
//session.SIR.location=LocationCD;
//session.SIR.ivr=IVRID;
session.SIR.location='LOCATION';
session.SIR.ivr='IVR';
//Application Updatable Variables 
session.SIR.callCompletionCD='NORMAL';
session.SIR.CheckpointBitField=0;
session.SIR.userDefined1='';
session.SIR.userDefined2='';
session.SIR.userDefined3='';
session.SIR.lineOutId=0;
session.SIR.dnisExt=0;
session.SIR.speechDipTime = '';
session.SIR.transferTime = '';
session.SIR.isoLanguageCD = 'ENG';
session.SIR.termCheckpoint = '';
session.SIR.requestKey = '';